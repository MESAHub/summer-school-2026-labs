#!/usr/bin/env bash
#
# Starter template for Friday Lab 2 bonus tasks.
# Spots to fill in the blank are marked with # !!!

set -e

# Set input parameters.
mod_dir="" # !!! Add the path to your mod_dir from Lab 1.

# Require a real mod_dir.
if [ ! -d "$mod_dir" ]; then
	echo "Missing mod_dir: $mod_dir"
	exit 1
fi

# Output file written by run_star_extras.
out_file='RSP.dat'

# Remove output file from previous runs
rm -f "$out_file"

# Write a fixed-width header in our output file.
printf '%s\n' '!!! Insert header info here' > "$out_file"

# Loop over each mod_file
for file in "$mod_dir"/*.mod
do
	if [ ! -e "$file" ]; then
		echo "No .mod files found in $mod_dir"
		exit 1
	fi

	mod_id="$(basename "$file" .mod)"
	echo "Doing $mod_id" # for initial set up
	# Get values of M, Teff, L, needed for RSP set up
	mod_num=$(echo "$mod_id" | cut -d '_' -f 1)
	# !!! Using the format of the previous line, set mass, teff, and lum.
	mass=
	teff=
	lum=

	echo $mass $teff

	# Use shmesa to update inlist_rsp_Cepheid.
	shmesa change inlist_rsp_Cepheid \
		set_initial_model_number .true. \
		initial_model_number "$mod_num" \
		RSP_mass "$mass" \
		RSP_Teff "$teff" \
		RSP_L "$lum"

	# Do the MESA run for this star
	./rn
done
