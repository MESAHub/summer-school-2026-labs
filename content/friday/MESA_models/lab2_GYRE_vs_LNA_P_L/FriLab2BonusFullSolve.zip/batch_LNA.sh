#!/usr/bin/env bash
#
# Partial Solutions for Friday lab 2 bonus tasks of the 2026 MESA summer school 
# Spots to fill in the blank are indicated with # !!!

# Set input paramters 
mod_dir="./mod_dir" # !!! Add the path to your mod_dir from lab 1 

# Set output file 
out_file="RSP.dat" # !!! Set the file name of our output file -- make sure it matches the value set in the inlist 

# Get list of mod files
mod_files=`ls $mod_dir/*.mod`

# Remove output file from previous runs
rm $out_file

# Write a header in our output file 
echo 'star_mass	luminosity	effective_temperature	F_period	F_growth	O1_period	O1_growth	O2_period	O2_growth' > $out_file

# Loop over each mod_file 
for file in $mod_files 
do 
	mod_id="$(basename $file .mod)"
	echo 'Doing ' $mod_id # for initial set up 
	# Get values of M, Teff, L, needed for RSP set up 
	mod_num=$(echo $mod_id | cut -d '_' -f 1) 

	# !!! Using the format of the previous line set values of mass, teff, and lum 
	mass=$(echo $mod_id | cut -d '_' -f 2) 
	teff=$(echo $mod_id | cut -d '_' -f 3) 
	lum=$(echo $mod_id | cut -d '_' -f 4) 

	# !!! Use shmesa to update inlist_rsp_Cepheid values of RSP_mass RSP_Teff RSP_L, 
	shmesa change inlist_rsp_Cepheid \
		RSP_mass $mass \
		RSP_Teff $teff \
		RSP_L $lum

	# Do the MESA run for this star 
	./rn 
done 

