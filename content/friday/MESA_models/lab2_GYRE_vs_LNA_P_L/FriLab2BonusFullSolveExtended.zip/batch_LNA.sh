#!/usr/bin/env bash

# Stop on script errors and undefined variables.
set -euo pipefail

# Empty globs give no files.
shopt -s nullglob

# Optionally pass the Lab 1 mod_dir and output file.
mod_dir="${1:-quick_mod_dir/}"
out_file="${2:-RSP.dat}"

if [[ ! -d "$mod_dir" ]]; then
	echo "Missing mod_dir: $mod_dir"
	exit 1
fi

# MESA writes to a local filename; copy to a requested path after the run.
mesa_out_file="$(basename "$out_file")"
final_out_file="$out_file"
failed_models_file="${mesa_out_file}.failed_models"

if [[ "$out_file" == */* ]]; then
	out_dir="$(dirname "$out_file")"
	mkdir -p "$out_dir"
	final_out_file="$(cd "$out_dir" && pwd)/$(basename "$out_file")"
fi

mod_files=("$mod_dir"/*.mod)
if [[ "${#mod_files[@]}" -eq 0 ]]; then
	echo "No .mod files found in $mod_dir"
	exit 1
fi

rm -f "$mesa_out_file" "$final_out_file" "$failed_models_file" "${final_out_file}.failed_models"

printf '%12s %20s %20s %20s %20s %20s %20s %20s %20s\n' \
	'model_number' 'star_mass' 'luminosity' 'Teff' 'RSP_W_VI' \
	'RSP_F_period' 'RSP_F_growth' 'RSP_F1_period' 'RSP_F1_growth' > "$mesa_out_file"

for file in "${mod_files[@]}"
do
	mod_id="$(basename "$file" .mod)"
	echo "Doing $mod_id"

	IFS=_ read -r mod_num mass teff lum <<< "$mod_id"
	if [[ -z "$mod_num" || -z "$mass" || -z "$teff" || -z "$lum" ]]; then
		echo "Unexpected .mod filename: $file"
		exit 1
	fi

	echo "$mass $teff"

	if ! shmesa change inlist_rsp_Cepheid \
		set_initial_model_number .true. \
		initial_model_number "$mod_num" \
		RSP_mass "$mass" \
		RSP_Teff "$teff" \
		RSP_L "$lum"
	then
		echo "Failed to update inlist_rsp_Cepheid for $mod_id"
		exit 1
	fi

	rows_before="$(awk 'NR > 1 && NF > 0 { count++ } END { print count + 0 }' "$mesa_out_file")"

	if ! RSP_LNA_OUTPUT_FILE="$mesa_out_file" ./rn; then
		echo "$mod_id ./rn failed" >> "$failed_models_file"
		echo "./rn failed for $mod_id; continuing"
		continue
	fi

	rows_after="$(awk 'NR > 1 && NF > 0 { count++ } END { print count + 0 }' "$mesa_out_file")"
	if [[ "$rows_after" -le "$rows_before" ]]; then
		echo "$mod_id no data row" >> "$failed_models_file"
		echo "No data row was written for $mod_id; continuing"
		continue
	fi
done

if [[ "$final_out_file" != "$(pwd)/$mesa_out_file" && "$final_out_file" != "$mesa_out_file" ]]; then
	cp "$mesa_out_file" "$final_out_file"
	if [[ -f "$failed_models_file" ]]; then
		cp "$failed_models_file" "${final_out_file}.failed_models"
	fi
fi
